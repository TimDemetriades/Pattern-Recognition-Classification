load('hw3_2_1_results.mat')
surf(x,y,z2)
